//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef __POINT2POINT_P2PENTITY_H_
#define __POINT2POINT_P2PENTITY_H_

#include <omnetpp.h>

#include "dataframe_m.h"
#include "ackframe_m.h"
#include "nackframe_m.h"

#include <vector>

using namespace omnetpp;

struct ReTXInfo {
    dataframe * df;
    cMessage  * timer;
};

enum Roles { TXRX = 1, TXONLY = 2, RXONLY = 3 };

class P2pentity : public cSimpleModule
{
  private:
    int N_S;
    int N_R;
    int N_A;
    int WindowSize;
    Roles Role;
    int FrameSize;
    int ARQMode;
    double Timeout;
    bool recoverymode;
    bool verbose;

    int receivedbits;
    double busystart, busysum;

    cMessage * txend;
    cMessage * kickstart;

    std::vector<struct ReTXInfo *> ReTXQueue;
    cPacketQueue * Priority;
    cPacketQueue * OoSQueue;   // Packet queue for out-of-sequence received

    simsignal_t throughput_sgnl;
    simsignal_t utilisation_sgnl;

  protected:
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;
    ~P2pentity();   // Destructor
};

#endif
